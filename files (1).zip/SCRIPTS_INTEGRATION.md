# Scripts Page — CRM Integration Guide

## 1. Drop the component file
Copy `ScriptsPage.jsx` into your components or pages directory:
```
src/pages/ScriptsPage.jsx
   — or —
src/components/ScriptsPage.jsx
```

---

## 2. Add the route

### React Router v6 (most common)
```jsx
// In your router file (e.g. App.jsx or router.jsx)
import ScriptsPage from "./pages/ScriptsPage";

<Route path="/scripts" element={<ScriptsPage />} />
```

### Next.js App Router
```
Place the file at: app/scripts/page.jsx
The route /scripts is auto-registered.
```

### Next.js Pages Router
```
Place the file at: pages/scripts.jsx
```

---

## 3. Add to the Agent Sidebar

Find your sidebar nav component (likely something like `Sidebar.jsx`, `AgentNav.jsx`, or `DashboardLayout.jsx`).

Add a nav item alongside existing agent nav links:

```jsx
// Example — adapt to your exact sidebar structure
import { Link, useLocation } from "react-router-dom";
import { FileText } from "lucide-react"; // or whatever icon library you use

const navItems = [
  // ... your existing items ...
  {
    label: "Scripts",
    href: "/scripts",
    icon: <FileText size={16} />,
  },
];

// In your sidebar render:
{navItems.map(item => (
  <Link
    key={item.href}
    to={item.href}
    className={`nav-item ${location.pathname.startsWith(item.href) ? "active" : ""}`}
  >
    {item.icon}
    <span>{item.label}</span>
  </Link>
))}
```

---

## 4. Layout note

`ScriptsPage` renders its own full-height layout with an internal two-column UI (step sidebar + content). It expects to fill a `height: 100%` or `height: 100vh` container.

If your CRM wraps pages in a shared layout that already has a top navbar + sidebar, you may want to pass `ScriptsPage` as a full-bleed child or set `overflow: hidden` on its route wrapper to avoid double scrollbars.

Example wrapper adjustment:
```jsx
// If your layout adds padding/overflow, override for this route:
<Route
  path="/scripts"
  element={
    <div style={{ height: "100%", overflow: "hidden" }}>
      <ScriptsPage />
    </div>
  }
/>
```

---

## 5. Font dependency

The component imports Google Fonts (Syne + DM Mono) via a `<style>` tag. If your CRM already loads these fonts globally, you can remove the `FONTS` constant and the `<style>{FONTS}</style>` tag at the top of the return block.

---

## 6. No external dependencies required

`ScriptsPage.jsx` only uses:
- React (`useState`, `useCallback`) — already in your project
- Inline styles — no CSS modules or Tailwind required
- Google Fonts — loaded via `@import` in a style tag

No additional `npm install` needed.

---

## Feature summary

| Feature | Live Transfer | Webform |
|---|---|---|
| Step-by-step navigation | ✅ 8 steps | ✅ 7 steps |
| Progress dots | ✅ | ✅ |
| Sidebar step nav | ✅ | ✅ |
| Qualification checklist | ✅ Pass / Fail / Warn buttons | — |
| Hard DQ protocol | ✅ Auto-triggers on fail | — |
| Qual reset | ✅ | — |
| Objection accordion | ✅ All sections | ✅ All sections |
| Objection filter tabs | ✅ | — |
| Path A / Path B split | ✅ | ✅ |
| Live walkthrough steps | ✅ | ✅ |
| Agent info settings | ✅ Modal | ✅ Inline inputs |
| Agent info in footer | ✅ | ✅ |
| Info displayed on final step | ✅ | ✅ |
| Accent color | Orange `#f0a060` | Green `#c8f060` |
| Tab switching | ✅ Both scripts in one page | |
